/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package productmng;

import java.util.Scanner;

/**
 *
 * @author baohc
 */
public class InputProduct {

    public static Scanner sc = new Scanner(System.in);

    public static String inputName(String msg, String pattern) {
        String name ="";
        do {
            System.out.print(msg);
            name = sc.nextLine();
           
        } while (name.contains(pattern));
        return name;
    }

    public static String inputID(String msg) {
        System.out.print(msg);
        Scanner sc = new Scanner(System.in);
        String id = sc.nextLine();
        return id;
    }

    public static double inputPrice(String msg, int min, int max) {
        double price;
        System.out.print(msg);
        do {
            Scanner sc = new Scanner(System.in);
            price = sc.nextDouble();
        } while (price < min && price > max);
        return price;
    }

    public static int inputQuantity(String msg, int min, int max) {
        int quantity;
        System.out.print(msg);
        do {

            Scanner sc = new Scanner(System.in);
            quantity = sc.nextInt();
        } while (quantity < min && quantity > max);
        return quantity;
    }
    
    public static String inputStatus(String name, String id, double price, int quantity){
        String status = "UnAvaliable";
        
        if (!name.isEmpty() && !id.isEmpty() && price >= 0 && quantity >= 0) {
            status = "Avaliable";
        }
        
        return status;
    }

}
