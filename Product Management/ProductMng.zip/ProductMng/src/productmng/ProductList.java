/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package productmng;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author baohc
 */
public class ProductList extends ArrayList<Product> {

    public ProductList() {
        super();
    }

    ArrayList<Product> list = new ArrayList<>();

    public Product searchName(String name) {
        name = name.trim();

        for (int i = 0; i < list.size(); i++) {

            if (list.get(i).getProductName().equals(name)) {
                return list.get(i);

            }
        }
        return null;
    }

    private boolean isNameDupplicated(String name) {

        name = name.trim();

        return searchName(name) != null;

    }

    public Product searchID(String id) {
        id = id.trim();

        for (int i = 0; i < this.size(); i++) {

            if (list.get(i).getProductID().equals(id)) {

                return this.get(i);

            }
        }
        return null;
    }

    private boolean isIDDupplicated(String id) {

        id = id.trim();

        return searchID(id) != null;

    }

    public void print() {
        if (list.isEmpty()) {
            System.out.println("List of Product is empty");
        } else {
            for (int i = 0; i < list.size(); i++) {
                System.out.println(list.get(i));
            }
        }
    }

    public void createProduct() {
        String newName, newID, newStatus;
        double newUnitPrice;
        int newQuantity;

        // Input Name
        do {

            newName = InputProduct.inputName("Product Name: ", " ");
            newName = newName.trim();

            if (isNameDupplicated(newName)) {
                System.out.println("Name is duplicated!");
            }

        } while (isNameDupplicated(newName) == true && newName.length() < 5);

        //Input ID
        do {

            newID = InputProduct.inputID("Product ID: ");
            newID = newID.trim();

            if (isIDDupplicated(newID)) {
                System.out.print("ID is duplicated");
            }

        } while (isIDDupplicated(newID));

        //Input UnitPrice
        newUnitPrice = InputProduct.inputPrice("Unit Price: ", 0, 1000);
        //Input Quantity
        newQuantity = InputProduct.inputQuantity("Quantity: ", 0, 1000);
        //Input Status

        newStatus = InputProduct.inputStatus(newName, newID, newUnitPrice, newQuantity);

        Product product = new Product(newID, newName, newUnitPrice, newQuantity, newStatus);
        list.add(product);

    }

    public void checkExitsProduct() {
        String checkName = InputProduct.inputName("Name to check: ", " ");

        File file = new File("ProductData.txt");
        try {
            Scanner sc = new Scanner(file);
            String product = "";
            String[] productInFile;
            String nameInFile = "";
            while (sc.hasNextLine()) {
                product = sc.nextLine();
                productInFile = product.split("\\s");
                nameInFile += productInFile[1] + " ";
            }

            if (nameInFile.contains(checkName)) {
                System.out.print("Exits");
            } else {
                System.out.print("No found");
            }

        } catch (FileNotFoundException ex) {
            Logger.getLogger(ProductList.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void searchProductByName() {
        String searchName = InputProduct.inputName("Name to search: ", " ");
        File file = new File("ProductData.txt");
        if (file.length() == 0) {
            System.out.println("Have no any Product");
        } else {

            try {

                Scanner sc = new Scanner(file);
                String product = "";
                String singleOfProduct = "";
                while (sc.hasNextLine()) {
                    product = sc.nextLine();
                    singleOfProduct += product + "\n";
                }

                String[] check = singleOfProduct.split("\\\n");

                for (int i = 0; i < check.length; i++) {
                    if (check[i].contains(searchName)) {
                        System.out.println(check[i]);
                    }
                }

            } catch (FileNotFoundException ex) {
                Logger.getLogger(ProductList.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    public void updateProduct() {
        String updateID = InputProduct.inputID("ID to update: ");
        for (int i = 0; i < list.size(); i++) {
            if (list.get(i).getProductID().equals(updateID)) {
                System.out.println(list.get(i));
                String newName = InputProduct.inputName("New Name: ", " ");
                String newID = InputProduct.inputID("New ID: ");
                double newPrice = InputProduct.inputPrice("New price: ", 0, 1000);
                int newQuantity = InputProduct.inputQuantity("New quantity: ", 0, 1000);

                list.get(i).setProductID(newID);
                list.get(i).setProductName(newName);
                list.get(i).setQuantity(newQuantity);
                list.get(i).setUnitPrice(newPrice);

            }
        }
    }

    public void deleteProduct() {
        String idDelete = InputProduct.inputID("ID to delete: ");
        for (int i = 0; i < list.size(); i++) {
            if (list.get(i).getProductID().equals(idDelete)) {
                list.remove(i);
            }
        }
    }

    public void saveProductToFile() {

        try {
            FileWriter writer = new FileWriter("ProductData.txt");
            BufferedWriter output = new BufferedWriter(writer);

            for (int i = 0; i < list.size(); i++) {
                output.write(list.get(i).toString() + "\n");
            }
            output.close();

        } catch (IOException ex) {
            Logger.getLogger(ProductList.class
                    .getName()).log(Level.SEVERE, null, ex);
        }

    }

    public void printListProductFromFile() {

        File file = new File("ProductData.txt");
        if (file.length() <= 0) {
            System.out.println("File is empty");
        } else {
            try {
                Scanner sc = new Scanner(file);
                String product = "";
                while (sc.hasNextLine()) {
                    product = sc.nextLine();
                    System.out.println(product);
                }

            } catch (FileNotFoundException ex) {
                Logger.getLogger(ProductList.class.getName()).log(Level.SEVERE, null, ex);
            }
        }

    }

}
